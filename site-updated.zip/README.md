# TextTools Online

A free online text processing tools platform with 6 tools.

## Deployment

This is a static site. Deploy to Vercel:

1. Install Vercel CLI: 
pm install -g vercel
2. Run: cd site && vercel --prod
3. Connect your domain quiktexttools.top in Vercel dashboard

## Files

- index.html - Homepage with tool grid and SEO content
- word-counter.html - Word, character, sentence, paragraph counter
- case-converter.html - 6 case conversion formats
- 	ext-diff.html - Line-by-line text comparison
- markdown-preview.html - Live Markdown editor with preview
- 	ext-replacer.html - Find & replace with regex support
- list-sorter.html - Sort, shuffle, deduplicate lists
- bout.html - About page
- contact.html - Contact page
- privacy.html - Privacy policy
- 	erms.html - Terms of service
- obots.txt - Search engine robots
- sitemap.xml - XML sitemap
